package com.github.p4535992.mvc.controller.gtfs;

import org.onebusaway.gtfs.impl.GtfsDaoImpl;
import org.onebusaway.gtfs.model.Agency;
import org.onebusaway.gtfs.services.GtfsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.inject.Inject;
import java.util.Collection;


@Controller
@RequestMapping("/agencies")
public class AgenciesController {

   public  AgenciesController(){}

  /* @Autowired
   @Qualifier("gtfs")*/

   private GtfsDaoImpl gtfs;

   @RequestMapping(method = RequestMethod.GET)
   public @ResponseBody
   Collection<Agency> allAgencies() {
      return this.gtfs.getAllAgencies();
   }// End of allAgencies method
}// End of controller
