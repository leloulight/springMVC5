
package com.github.p4535992.mvc.controller.gtfs;

import org.onebusaway.gtfs.impl.GtfsDaoImpl;
import org.onebusaway.gtfs.model.AgencyAndId;
import org.onebusaway.gtfs.model.ServiceCalendarDate;
import org.onebusaway.gtfs.model.StopTime;
import org.onebusaway.gtfs.model.Trip;
import org.onebusaway.gtfs.model.calendar.ServiceDate;
import org.onebusaway.gtfs.services.GtfsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.*;

@Controller
@RequestMapping("/stop-times")
public class StopTimesController
{

    public StopTimesController(){}


    private GtfsDaoImpl gtfs;

   @RequestMapping(method = RequestMethod.GET)
   public @ResponseBody Collection<StopTime> allStopTimes(@RequestParam(required = false) String trip) {
      return this.gtfs.getAllStopTimes();
   }// End of allStopTimes method

   @RequestMapping(method = RequestMethod.GET, params = {"date", "stop"})
   public @ResponseBody Collection<StopTime> allStopTimes(@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,
                                                          @RequestParam String stop) {
      List<StopTime> stopTimes = new ArrayList<>();
      ServiceCalendarDate serviceIds = this.gtfs.getCalendarDateForId(0);
      serviceIds.setDate(new ServiceDate(date));
      //List<String> serviceIDs = this.gtfs.get
      List<Trip> trips = (List<Trip>) this.gtfs.getAllTrips();
     /* for (Trip trip : trips) {
         Collection<StopTime> tripStopTimes = this.gtfs.getStopTimeForId(trip.getBikesAllowed());
         if (tripStopTimes.containsKey(stop)) {
            stopTimes.add(tripStopTimes.get(stop));
         }// End of if
      }// End of for

*/
      return stopTimes;
   }// End of allStopTimes method
}// End of class
