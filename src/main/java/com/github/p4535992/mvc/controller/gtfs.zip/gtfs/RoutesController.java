package com.github.p4535992.mvc.controller.gtfs;

import org.onebusaway.gtfs.impl.GtfsDaoImpl;
import org.onebusaway.gtfs.model.AgencyAndId;
import org.onebusaway.gtfs.model.Route;
import org.onebusaway.gtfs.services.GtfsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.inject.Inject;
import java.util.Collection;

@Controller
@RequestMapping("/routes")
public class RoutesController {

   public RoutesController(){}


   private GtfsDaoImpl gtfs;

   @RequestMapping(method = RequestMethod.GET)
   public @ResponseBody Collection<Route> allRoutes() {
      return this.gtfs.getAllRoutes();
   }// End of allRoutes method

   @RequestMapping(value = "/{routeId}", method = RequestMethod.GET)
   public @ResponseBody Route singleRoute(@PathVariable String routeId) {
      return this.gtfs.getRouteForId(new AgencyAndId("",routeId));
   }// End of allRoutes method
}// End of class
