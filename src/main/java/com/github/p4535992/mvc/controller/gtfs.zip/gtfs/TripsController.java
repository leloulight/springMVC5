package com.github.p4535992.mvc.controller.gtfs;

import org.onebusaway.gtfs.impl.GtfsDaoImpl;
import org.onebusaway.gtfs.model.AgencyAndId;
import org.onebusaway.gtfs.model.ServiceCalendarDate;
import org.onebusaway.gtfs.model.Trip;
import org.onebusaway.gtfs.model.calendar.ServiceDate;
import org.onebusaway.gtfs.services.GtfsDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/trips")
public class TripsController
{
   public TripsController(){}

   private GtfsDaoImpl gtfs;

   @RequestMapping(method = RequestMethod.GET)
   public @ResponseBody Collection<Trip> allTrips(@RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
      if (date == null){
         return this.gtfs.getAllTrips();
      }// End of if
      else {
         List<Trip> trips = new ArrayList<Trip>();
         ServiceCalendarDate serviceIds = this.gtfs.getCalendarDateForId(0);
         serviceIds.setDate(new ServiceDate(date));
         trips.add(this.gtfs.getTripForId(serviceIds.getServiceId()));
         return trips;
      }// End of else
   }// End of allTripsForDate method

   @RequestMapping(value = "/{tripId}", method = RequestMethod.GET)
   public @ResponseBody Trip singleTrip(@PathVariable String tripId){
      return this.gtfs.getTripForId(new AgencyAndId("",tripId));
   }// End of singleTrip method
}// End of class
